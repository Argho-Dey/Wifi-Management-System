package interfaces;

public interface IUserOperation {

    public void displayUsers();
    public void searchUser();
    public void deleteUser();


}
