package interfaces;

public interface IPackageOperations
{
	void displayPackages();
	void searchPackage();
	void deletePackage();
}