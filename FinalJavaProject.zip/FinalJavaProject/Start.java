import Classes.*;

import java.lang.*;
public class Start {
    public static void main(String[] args) {

                new Login();
//            new Registration();
//        new AddPackage();
//        new ManageUsers();
//        new ManagePackages();
//        new AdminPanel();
//        new ContactUs();
//        new NewConnection();
//        new Payment();
//        new AddPackage();
    }
}
